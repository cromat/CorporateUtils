window.addEventListener('getPageData', function(event) {
	var pageData = {};
	pageData.satellite = {};
	if(window._satellite) {
		pageData.satellite.propertyName = _satellite.property.name;
		pageData.satellite.environment = _satellite.environment.stage;
		pageData.satellite.buildDate = _satellite.buildInfo.buildDate;
	}
	window.postMessage({ action: 'pageData', payload: pageData }, '*');
}, false);
