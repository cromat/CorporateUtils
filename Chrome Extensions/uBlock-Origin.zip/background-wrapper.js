// noinspection ES6UnusedImports,NpmUsedModulesInstalled

// eslint-disable-next-line no-unused-vars
import * as service from "BACKGROUND_SCRIPT";
