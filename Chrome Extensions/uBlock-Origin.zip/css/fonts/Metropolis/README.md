# Metropolis

A modern, geometric typeface. Influenced by other popular geometric, minimalist sans-serif typefaces of the new millennium. Designed for optimal readability at small point sizes while beautiful at large point sizes.

![Metropolis](./Specimens/Metro-1.png)

---

![Metropolis](./Specimens/Metro-2.png)

### Where am I?

See [Documentation](./Documentation/Documentation.md).

### The Unlicense

Contributions welcome.

### Contact

Reachable via chris.m.simpson [at] icloud.com or tweet @ChrisMSimpson.

### Support

There is none. Oh, you meant support me? I dare you to click the sponsor button above.
